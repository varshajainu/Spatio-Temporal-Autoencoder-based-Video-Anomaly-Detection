please put the testing videos in file testing_videos

Thus, run ground_truth_show